import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;


public class FormIn {
	
    @Test
	public void testform() throws InterruptedException {
		System.setProperty("webdriver.gecko.driver","C:/geckodriver.exe");
	
		WebDriver driver = new FirefoxDriver();
		driver.get("https://inm-test-app.herokuapp.com/accounts/login/");
		
        //Cadastrar novo login
		driver.findElement(By.xpath("//a[contains(text(),'Cadastre-se')]")).click(); 
		Thread.sleep(1000);
		driver.findElement(By.name("username")).click();
		driver.findElement(By.name("username")).sendKeys("Usuario001");
		driver.findElement(By.name("pass")).click();
		driver.findElement(By.name("pass")).sendKeys("123456");
		driver.findElement(By.name("confirmpass")).click();
		driver.findElement(By.name("confirmpass")).sendKeys("123456");
		Thread.sleep(1000);
		WebElement ButtonId1 = driver.findElement(By.xpath("//button[contains(.,'Cadastrar')]"));
		ButtonId1.click();
		Thread.sleep(1000);
			
		//Logar com usu�rio existente	 
		 driver.findElement(By.name("username")).click();
			driver.findElement(By.name("username")).sendKeys("Usuario001");
			driver.findElement(By.name("pass")).click();
			driver.findElement(By.name("pass")).sendKeys("123456");		 
		 WebElement ButtonId2= driver.findElement(By.xpath("//button[contains(.,'Entre')]"));
		 ButtonId2.click();
		 Thread.sleep(1000);
		 
		 //Cadastrar novo Funcion�rio
		 driver.findElement(By.xpath("//a[contains(text(),'Novo Funcion�rio')]")).click(); 
		 driver.findElement(By.id("inputNome")).click();
		 driver.findElement(By.id("inputNome")).sendKeys("Teste Func 004");
		 driver.findElement(By.id("cpf")).click();
		 driver.findElement(By.id("cpf")).sendKeys("447.022.080-98");
		 driver.findElement(By.id("inputCargo")).click();
		 driver.findElement(By.id("inputCargo")).sendKeys("Analista");
		 driver.findElement(By.id("dinheiro")).click();
		 driver.findElement(By.id("dinheiro")).sendKeys("2.500,00");
		 driver.findElement(By.id("slctSexo")).click();
		 driver.findElement(By.xpath("//select[@id='slctSexo']/option[3]")).click();
		 driver.findElement(By.id("clt")).click();
		 driver.findElement(By.id("inputAdmissao")).click();
		 driver.findElement(By.id("inputAdmissao")).sendKeys("02/02/2020");
		 driver.findElement(By.xpath("//input[@type='submit']")).click(); 
		 Thread.sleep(1000);
		 
		 //Editar Funcion�rio existente - Alterar tipo de contrata��o
		 driver.findElement(By.xpath("//input[@type='search']")).click(); 
		 driver.findElement(By.xpath("//input[@type='search']")).sendKeys("Teste Func 004");
		 driver.findElement(By.xpath("//table[@id='tabela']/tbody/tr/td[6]/a[2]/button/span")).click();
		 Thread.sleep(1000);
		 driver.findElement(By.id("pj")).click();
		 Thread.sleep(1000);
		 driver.findElement(By.xpath("//input[@type='submit']")).click(); 
		 Thread.sleep(1000);
		 
		 //Remover funcion�rio existente
		 driver.findElement(By.xpath("//input[@type='search']")).click();
		 driver.findElement(By.xpath("//input[@type='search']")).sendKeys("Teste Func 004");
		 driver.findElement(By.id("delete-btn")).click();
		 Thread.sleep(1000); 	 		 
    }	

}
